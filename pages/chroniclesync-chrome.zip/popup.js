document.getElementById("openDashboard").addEventListener("click",()=>{chrome.tabs.create({url:"https://your-github-pages-url.com"})});
