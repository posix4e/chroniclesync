chrome.devtools.panels.create("ChronicleSync","icon-32.png","devtools.html",()=>{});
